package src.daomap;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import src.beans.BankBean;
import src.beans.Address;

@Repository("BankDao")
public class BankDao implements BankDao1 {

	@PersistenceContext(name = "persistone")
	private EntityManager con;

	@Override
	@Transactional
	public long getBalance(long accNo) {
		
		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));
		
		return emp1.getBalance();
	}

	@Override
	@Transactional
	public void setBalance(long accNo, long bal, String st) {

		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));
		String str = emp1.getTran() + st;
		emp1.setTran(str);
		emp1.setBalance(bal);
		con.merge(emp1);
	}

	@Override
	@Transactional
	public boolean checkPassword(String str, long accNo) {


		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));
		if (emp1.getPassword().equals(str))
			return true;
		else
			return false;

	}

	@Override
	@Transactional
	public boolean checkAccNo(long accNo) {

		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));

		if (emp1 == null)
			return false;
		else
			return true;

	}

	@Override
	@Transactional
	public long setData(BankBean bb) {
		con.persist(bb);
		return bb.getAccNo();
	}

	@Override
	@Transactional
	public String getTransaction(long accNo) {
		// TODO Auto-generated method stub

		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));

		return emp1.getTran();
	}
	
	@Override
	@Transactional
	public BankBean getInfo(long accNo) {
		// TODO Auto-generated method stub

		BankBean emp1 = (BankBean) con.find(BankBean.class, new Long(accNo));

		return emp1;
	}

}
